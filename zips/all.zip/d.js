file d.js
this is some js code
const fs = require("fs")